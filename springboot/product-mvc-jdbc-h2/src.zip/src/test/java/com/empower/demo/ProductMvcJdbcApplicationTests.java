package com.empower.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMvcJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
